双击HSPA_AHG.bat运行程序。

